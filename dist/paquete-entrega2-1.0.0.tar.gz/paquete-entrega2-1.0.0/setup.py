from setuptools import setup

setup(
    name = "paquete-entrega2",
    version = "1.0.0",
    description = "Creador de usuario y clase cliente",
    packages=["paquete"]
)
